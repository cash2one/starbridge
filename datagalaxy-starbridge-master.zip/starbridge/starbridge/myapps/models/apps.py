from django.apps import AppConfig


class ModelsConfig(AppConfig):
    name = 'myapps.models'
