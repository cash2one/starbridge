from django.apps import AppConfig


class ActivityConfig(AppConfig):
    name = 'myapps.activity'
    verbose_name = '   活动管理'