from django.apps import AppConfig


class StarConfig(AppConfig):
    name = 'myapps.star'
    verbose_name = '  明星管理'