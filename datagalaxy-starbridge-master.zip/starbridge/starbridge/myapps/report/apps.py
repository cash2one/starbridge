from django.apps import AppConfig


class ReportConfig(AppConfig):
    name = 'myapps.report'
    verbose_name = ' 报告管理'