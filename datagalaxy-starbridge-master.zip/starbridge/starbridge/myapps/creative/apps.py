from django.apps import AppConfig


class CreativeConfig(AppConfig):
    name = 'myapps.creative'
    verbose_name = '   素材管理'