from django.contrib import admin
from .models import CreativeWeibo, CreativeWeixin, CreativeZhibo, StarOrCelebrityCreative
# Register your models here.
admin.site.register(CreativeWeibo)
admin.site.register(CreativeWeixin)
admin.site.register(CreativeZhibo)
admin.site.register(StarOrCelebrityCreative)