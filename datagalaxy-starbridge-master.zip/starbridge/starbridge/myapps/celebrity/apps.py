from django.apps import AppConfig


class CelebrityConfig(AppConfig):
    name = 'myapps.celebrity'
    verbose_name = '  网红管理'